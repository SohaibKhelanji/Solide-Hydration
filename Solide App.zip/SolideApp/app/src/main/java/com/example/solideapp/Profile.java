package com.example.solideapp;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

public class Profile extends Fragment implements ChangePasswordDialogFragment.ChangePasswordListener {
    private TextView userName;
    private int userId;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);
        Button changePasswordButton = view.findViewById(R.id.changePasswordButton);
        userName = view.findViewById(R.id.userName);

        // Get userId from arguments
        userId = getArguments().getInt("userId", -1);

        TextView logoutButton = view.findViewById(R.id.logoutButton);

        logoutButton.setOnClickListener(v -> {
            // Restart the app by relaunching the main activity
            Intent intent = new Intent(requireContext(), MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            requireActivity().finish();
        });

        // Change password button click listener
        changePasswordButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Call the method to show the change password dialog
                showChangePasswordDialog();
            }
        });

        return view;
    }

    private void fetchUserData(int userId) {
        ApiManager apiManager = new ApiManager(requireContext());

        apiManager.getUserDataById(userId, new ApiManager.ApiResponseListener() {
            @Override
            public void onSuccess(JSONObject response) {
                try {
                    // Extract username from the API response
                    String username = response.getJSONArray("data").getJSONObject(0).getString("username");

                    // Update the userName TextView with the retrieved username
                    requireActivity().runOnUiThread(() -> userName.setText(username));

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onError(String errorMessage) {
                // Handle errors
            }
        });
    }

    // Modify this method to be triggered only when the button is clicked
    private void showChangePasswordDialog() {
        if (isAdded()) {
            ChangePasswordDialogFragment dialogFragment = ChangePasswordDialogFragment.newInstance();
            dialogFragment.setChangePasswordListener(this);
            dialogFragment.show(getChildFragmentManager(), "ChangePasswordDialogFragment");
        }
    }

    @Override
    public void onChangePassword(String newPassword) {
        // Call the method to initiate password change with the new password
        if (userId != -1) {
            initiatePasswordChange(requireContext(), userId, newPassword);
        }
    }

    private void initiatePasswordChange(Context context, int userId, String newPassword) {
        // Replace the following URL with your actual password change endpoint
        String passwordChangeApiUrl = "http://46.38.241.211:3000/api/user/change";

        ApiManager apiManager = new ApiManager(context);

        apiManager.changePassword(requireContext(), userId, newPassword, new ApiManager.ApiResponseListener() {
            @Override
            public void onSuccess(JSONObject response) {
                // Handle the success response
                Toast.makeText(requireContext(), "Password changed successfully", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onError(String errorMessage) {
                // Handle errors
                Toast.makeText(requireContext(), "Failed to change password: " + errorMessage, Toast.LENGTH_SHORT).show();
            }
        });
    }
}
