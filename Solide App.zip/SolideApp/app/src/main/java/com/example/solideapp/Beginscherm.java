package com.example.solideapp;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.solideapp.databinding.ActivityMainBinding;

import org.json.JSONException;
import org.json.JSONObject;


public class Beginscherm extends Fragment {

    ApiManager apiManager;
    private int userId; // Variable to store the user ID


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_beginscherm, container, false);


    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        if (getArguments() != null) {
            userId = getArguments().getInt("userId", -1);
            Log.d("BEGINSCHERM", "User ID in Fragment: " + userId); // Add this log statement
        }

        apiManager = new ApiManager(requireContext());

        getUserGoalAndUpdateUI();

        ImageView dailyGoalImageView = view.findViewById(R.id.dailyGoal);

        if (dailyGoalImageView != null) {
            dailyGoalImageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Call the method when the ImageView is clicked
                    showDailyGoalInputDialog();
                }
            });
        }

    }




    private void showDailyGoalInputDialog() {
        // Get the layout inflater
        LayoutInflater inflater = LayoutInflater.from(requireContext());
        View dialogView = inflater.inflate(R.layout.dialog_input, null);

        // Create an AlertDialog.Builder and set the view
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        builder.setView(dialogView);

        // Set the title
        builder.setTitle("Enter Daily Goal");

        // Set the positive button
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Get the entered value from the EditText
                EditText editText = dialogView.findViewById(R.id.editTextDailyGoal);
                String input = editText.getText().toString();

                // Validate the input (you can add your own validation logic here)
                if (!input.isEmpty()) {
                    // Call the APIManager method to update the user's goal
                    updateDailyGoal(input);
                } else {
                    // Display a toast for empty input or invalid input
                    Toast.makeText(requireContext(), "Invalid input", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Set the negative button
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Cancelled by the user
                dialog.cancel();
            }
        });

        // Create and show the dialog
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    // Method to update the user's daily goal using the APIManager
    private void updateDailyGoal(String newGoal) {
        // Validate that userId is not -1 (invalid)
        if (userId != -1) {
            // Call the APIManager method to update the user's goal
            apiManager.updateUserGoal(userId, newGoal, new ApiManager.ApiResponseListener() {
                @Override
                public void onSuccess(JSONObject response) {
                    // Handle successful response (if needed)
                    getUserGoalAndUpdateUI();
                    Toast.makeText(requireContext(), "Daily goal updated successfully", Toast.LENGTH_SHORT).show();
                }

                @Override
                public void onError(String errorMessage) {
                    // Log the error message for debugging
                    Log.e("Beginscherm", "Error updating daily goal: " + errorMessage);

                    // Handle error (if needed)
                    Toast.makeText(requireContext(), "Error updating daily goal: " + errorMessage, Toast.LENGTH_SHORT).show();
                }
            });
        } else {
            // Log an error or handle the case where userId is invalid
            Log.e("Beginscherm", "Invalid userId");
            Toast.makeText(requireContext(), "Invalid user ID", Toast.LENGTH_SHORT).show();
        }
    }

    // Method to get the user's goal and update the UI
    private void getUserGoalAndUpdateUI() {
        apiManager.getUserGoal(userId, new ApiManager.ApiResponseListener() {
            @Override
            public void onSuccess(JSONObject response) {
                try {
                    // Extract the goal value from the JSON response
                    int userGoal = response.getInt("data");

                    // Update the TextView with the user's goal
                    TextView usersGoalTextView = getView().findViewById(R.id.usersGoal);
                    if (usersGoalTextView != null) {
                        usersGoalTextView.setText(String.valueOf(userGoal));
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onError(String errorMessage) {
                // Log the error message for debugging
                Log.e("Beginscherm", "Error getting user's goal: " + errorMessage);
            }
        });
    }
}
