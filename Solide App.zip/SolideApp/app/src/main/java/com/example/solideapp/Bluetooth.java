package com.example.solideapp;

import android.graphics.Color;
import android.os.Bundle;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class Bluetooth extends Fragment {

    private TextView bluetoothConnectedTextView;
    private BluetoothConnection bluetoothConnection;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_bluetooth, container, false);

        // Find the TextView for Bluetooth connection status
        bluetoothConnectedTextView = rootView.findViewById(R.id.bluetoothConnectedTextView);

        // Initialize Bluetooth connection
        bluetoothConnection = new BluetoothConnection(getContext());

        // Call a function to check if Bluetooth is connected
        checkBluetoothConnection();

        return rootView;
    }

    private void checkBluetoothConnection() {
        // Replace "deviceAddress" with your actual Bluetooth device address
        String deviceAddress = "FF:95:E8:75:38:3A";

        // Check if Bluetooth is connected using the connectToDevice method
        boolean isConnected = bluetoothConnection.connectToDevice(deviceAddress);
        Log.d("testingbluetooth", String.valueOf(isConnected));

        if (isConnected) {
            // Update the TextView to show "connected"
            bluetoothConnectedTextView.setText("Connected");
            bluetoothConnectedTextView.setTextColor(Color.parseColor("#449655"));
        }
    }
}
